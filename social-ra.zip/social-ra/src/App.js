import { Admin, Resource } from "react-admin";
import lb4Provider from "react-admin-lb4";
import { ContaList } from "./contas";
import { PublicacaoList } from "./publicacaos";
import { VendaList } from "./vendas";

const dataProvider = lb4Provider("http://localhost:3000");

const App = () => {
  return(
    <Admin dataProvider={dataProvider}>
    <Resource name="conta" list={ContaList} />
    <Resource name="publicacaos" list={PublicacaoList} />
    <Resource name="vendas" list={VendaList} />
 </Admin>
  );

  };

export default App;

import {List, Datagrid, TextField, NumberField} from "react-admin";
   export const ContaList = (props) => (
    <List {...props}>
        <Datagrid rowClick="edit">
            <NumberField source="id" />
            <TextField source="nome"/>
            <TextField source="email"/>
            <TextField source="genero"/>
            <TextField source="senha"/>
        </Datagrid>
    </List>
   );
   
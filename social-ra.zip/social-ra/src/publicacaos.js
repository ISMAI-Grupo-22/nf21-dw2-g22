import {List, Datagrid, TextField, NumberField} from "react-admin";
   export const PublicacaoList = (props) => (
    <List {...props}>
      <Datagrid rowClick="edit">
         <NumberField source="id"/>
         <TextField source="nome"/>
         <TextField source="descricao"/>
      </Datagrid>
    </List>
   );
   